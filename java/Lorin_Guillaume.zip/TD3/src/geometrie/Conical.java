package geometrie;

public class Conical extends GeometricalShape{
    
}