package geometrie;

public class Triangle extends Polygon{
    
}