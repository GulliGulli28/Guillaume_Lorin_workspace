package geometrie;

public class GeometricalShape{

    public void draw(int zone){
        System.out.println("Drawing the "+ zone+ "th zone of a shape");
    }

    public void draw(){
        System.out.println("Drawing a geometrical shape");
    }
}