package geometrie;

public class Polygon extends GeometricalShape{
    
}