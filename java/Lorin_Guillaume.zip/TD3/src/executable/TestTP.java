package executable;

import geometrie.*;


public class TestTP {

	
	public static void main(String[] args) {
		
		//Using some point constructors 
		Point p1 = new Point(5.1, 2.0, "A");
		Point p2 = new Point();
		Point p3 = new Point (1.1,6.0);
		
		System.out.println("AFFICHAGE");
		//Printing for fun
		System.out.println(p1.toString() );
		System.out.println(p1);
		Integer i;
		Rectangle r = new Rectangle();
		/**r.draw(4);
		r.draw();
		r.draw(new Point());
		Quadrilateral quad = new Quadrilateral();
		double perquad = quad.getPerimeter();

		quad = new Rectangle();
		double perrec = quad.getPerimeter();

		GeometricalShape [] listfig = new GeometricalShape[3];
		listfig[0] = new Rectangle();
		listfig[1] = new Quadrilateral();
		listfig[2] = new Ellipse();

		Rectangle rec = new Quadrilateral();
		*/

		

	}

}
