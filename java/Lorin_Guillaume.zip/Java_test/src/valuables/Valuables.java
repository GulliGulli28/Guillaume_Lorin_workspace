package valuables;

public interface Valuables{
    public abstract double getValue();

}