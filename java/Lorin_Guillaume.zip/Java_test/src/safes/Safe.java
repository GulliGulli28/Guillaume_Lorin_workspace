package safes;
import valuables;

public class Safe implements Valuables{


}